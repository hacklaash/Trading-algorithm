# Trading-Algo
Trading with Zerodha API
